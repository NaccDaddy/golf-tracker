import { useState } from 'react';

export default function App() {
  const [courses, setCourses] = useState([]);
  const [input, setInput] = useState('');

  const handleAdd = () => {
    if (input.trim()) {
      setCourses([...courses, input.trim()]);
      setInput('');
    }
  };

  return (
    <div style={{ padding: '1rem', fontFamily: 'Arial' }}>
      <h1>Simple Golf Tracker</h1>
      <input
        type="text"
        placeholder="Enter course name"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        style={{ padding: '0.5rem', width: '80%' }}
      />
      <button onClick={handleAdd} style={{ padding: '0.5rem', marginLeft: '0.5rem' }}>
        Add Course
      </button>

      <h2 style={{ marginTop: '2rem' }}>Courses You've Played</h2>
      <ul>
        {courses.map((course, index) => (
          <li key={index}>{course}</li>
        ))}
      </ul>
    </div>
  );
}